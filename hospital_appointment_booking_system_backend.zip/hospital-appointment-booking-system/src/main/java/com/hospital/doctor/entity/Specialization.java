package com.hospital.doctor.entity;

public enum Specialization {

    CARDIOLOGIST,
    DERMATOLOGIST,
    ENT,
    GYNECOLOGIST,
    NEUROLOGIST,
    ONCOLOGIST,
    OPHTHALMOLOGIST,
    ORTHOPEDIC,
    PEDIATRICIAN,
    PHYSICIAN,
    PSYCHIATRIST,
    RADIOLOGIST,
    SURGEON,
    UROLOGIST
}