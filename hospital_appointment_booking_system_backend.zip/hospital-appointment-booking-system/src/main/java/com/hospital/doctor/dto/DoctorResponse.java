package com.hospital.doctor.dto;

import com.hospital.doctor.entity.Specialization;
import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class DoctorResponse {

    private Long id;

    private String firstName;

    private String lastName;

    private String email;

    private String phoneNumber;

    private Specialization specialization;

    private Integer experience;

    private Double consultationFee;

    private Boolean available;
}