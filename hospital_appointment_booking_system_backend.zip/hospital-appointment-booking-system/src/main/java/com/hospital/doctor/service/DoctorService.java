package com.hospital.doctor.service;

import com.hospital.doctor.dto.DoctorRequest;
import com.hospital.doctor.dto.DoctorResponse;
import com.hospital.doctor.entity.Specialization;

import java.util.List;

public interface DoctorService {

    DoctorResponse addDoctor(DoctorRequest request);

    List<DoctorResponse> getAllDoctors();

    DoctorResponse getDoctorById(Long id);

    List<DoctorResponse> getDoctorsBySpecialization(Specialization specialization);

    List<DoctorResponse> getAvailableDoctors();
}