package com.hospital.doctor.service.impl;

import com.hospital.doctor.dto.DoctorRequest;
import com.hospital.doctor.dto.DoctorResponse;
import com.hospital.doctor.entity.Doctor;
import com.hospital.doctor.exception.DoctorAlreadyExistsException;
import com.hospital.doctor.exception.DoctorNotFoundException;
import com.hospital.doctor.mapper.DoctorMapper;
import com.hospital.doctor.repository.DoctorRepository;
import com.hospital.doctor.service.DoctorService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import com.hospital.doctor.entity.Specialization;
import java.util.List;

@Service
@RequiredArgsConstructor
public class DoctorServiceImpl implements DoctorService {

    private final DoctorRepository doctorRepository;
    private final DoctorMapper doctorMapper;

    @Override
    public DoctorResponse addDoctor(DoctorRequest request) {

        if (doctorRepository.existsByEmail(request.getEmail())) {
            throw new DoctorAlreadyExistsException("Doctor email already exists");
        }

        if (doctorRepository.existsByPhoneNumber(request.getPhoneNumber())) {
            throw new DoctorAlreadyExistsException("Doctor phone number already exists");
        }

        Doctor doctor = doctorMapper.toEntity(request);

        Doctor savedDoctor = doctorRepository.save(doctor);

        return doctorMapper.toResponse(savedDoctor);
    }

    @Override
    public List<DoctorResponse> getAllDoctors() {

        return doctorRepository.findAll()
                .stream()
                .map(doctorMapper::toResponse)
                .toList();
    }

    @Override
    public DoctorResponse getDoctorById(Long id) {

        Doctor doctor = doctorRepository.findById(id)
                .orElseThrow(() -> new DoctorNotFoundException("Doctor not found"));

        return doctorMapper.toResponse(doctor);
    }
    @Override
    public List<DoctorResponse> getDoctorsBySpecialization(Specialization specialization) {

        return doctorRepository.findBySpecialization(specialization)
                .stream()
                .map(doctorMapper::toResponse)
                .toList();
    }
    @Override
    public List<DoctorResponse> getAvailableDoctors() {

        return doctorRepository.findByAvailableTrue()
                .stream()
                .map(doctorMapper::toResponse)
                .toList();
    }
}