package com.hospital.doctor.repository;

import com.hospital.doctor.entity.Doctor;
import com.hospital.doctor.entity.Specialization;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface DoctorRepository extends JpaRepository<Doctor, Long> {

    boolean existsByEmail(String email);

    boolean existsByPhoneNumber(String phoneNumber);

    List<Doctor> findBySpecialization(Specialization specialization);

    List<Doctor> findByAvailableTrue();
}