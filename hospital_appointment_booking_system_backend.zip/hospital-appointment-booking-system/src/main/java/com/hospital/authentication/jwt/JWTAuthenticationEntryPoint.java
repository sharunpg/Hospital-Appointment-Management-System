package com.hospital.authentication.jwt;

public class JWTAuthenticationEntryPoint {
}
