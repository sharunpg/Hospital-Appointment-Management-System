package com.hospital.authentication.jwt;

import com.hospital.user.entity.Role;

public interface JwtService {

    String generateToken(String email, Role role);

    String extractUsername(String token);

    String extractRole(String token);

    boolean isTokenValid(String token);
}