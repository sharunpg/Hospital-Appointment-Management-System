package com.hospital.authentication.service;

import com.hospital.authentication.dto.LoginRequest;
import com.hospital.authentication.dto.LoginResponse;
import com.hospital.authentication.jwt.JwtService;
import com.hospital.user.entity.User;
import com.hospital.user.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class AuthenticationServiceImpl implements AuthenticationService {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    private final JwtService jwtService;

    @Override
    public LoginResponse login(LoginRequest request) {

        User user = userRepository.findByEmail(request.getEmail())
                .orElseThrow(() ->
                        new BadCredentialsException("Invalid Email or Password"));

        if (!passwordEncoder.matches(request.getPassword(), user.getPassword())) {
            throw new BadCredentialsException("Invalid Email or Password");
        }

        String token = jwtService.generateToken(
                user.getEmail(),
                user.getRole());

        return LoginResponse.builder()
                .token(token)
                .message("Login Successful")
                .build();

    }
}