package com.hospital.authentication.service;

import com.hospital.authentication.dto.LoginRequest;
import com.hospital.authentication.dto.LoginResponse;

public interface AuthenticationService {

    LoginResponse login(LoginRequest request);

}