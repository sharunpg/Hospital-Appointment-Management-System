package com.hospital.appointment.mapper;

import com.hospital.appointment.dto.AppointmentRequest;
import com.hospital.appointment.dto.AppointmentResponse;
import com.hospital.appointment.entity.Appointment;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(componentModel = "spring")
public interface AppointmentMapper {

    @Mapping(target = "id", ignore = true)
    @Mapping(target = "patient", ignore = true)
    @Mapping(target = "doctor", ignore = true)
    @Mapping(target = "status", ignore = true)
    Appointment toEntity(AppointmentRequest request);

    @Mapping(source = "patient.firstName", target = "patientName")
    @Mapping(source = "doctor.firstName", target = "doctorName")
    AppointmentResponse toResponse(Appointment appointment);
}