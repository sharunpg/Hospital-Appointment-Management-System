package com.hospital.user.entity;

public enum Role {
    PATIENT,
    DOCTOR,
    ADMIN
}