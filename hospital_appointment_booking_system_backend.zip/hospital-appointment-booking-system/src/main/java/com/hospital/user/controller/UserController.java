package com.hospital.user.controller;

import com.hospital.user.dto.RegisterRequest;
import com.hospital.user.dto.UserResponse;
import com.hospital.user.service.UserService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/users")
@RequiredArgsConstructor
public class UserController {

    private final UserService userService;

    @PostMapping("/register")
    public ResponseEntity<UserResponse> register(
            @Valid @RequestBody RegisterRequest request) {

        return new ResponseEntity<>(
                userService.register(request),
                HttpStatus.CREATED);
    }

    @PreAuthorize("isAuthenticated()")
    @GetMapping("/profile")
    public ResponseEntity<String> profile(Authentication authentication) {

        return ResponseEntity.ok(
                "Logged in as: " + authentication.getName());
    }
}