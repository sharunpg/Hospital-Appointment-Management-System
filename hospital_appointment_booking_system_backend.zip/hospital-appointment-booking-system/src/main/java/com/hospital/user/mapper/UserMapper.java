package com.hospital.user.mapper;

import com.hospital.user.dto.RegisterRequest;
import com.hospital.user.dto.UserResponse;
import com.hospital.user.entity.User;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(componentModel = "spring")
public interface UserMapper {

    @Mapping(target = "id", ignore = true)
    @Mapping(target = "password", ignore = true)
    User toEntity(RegisterRequest request);

    UserResponse toResponse(User user);
}