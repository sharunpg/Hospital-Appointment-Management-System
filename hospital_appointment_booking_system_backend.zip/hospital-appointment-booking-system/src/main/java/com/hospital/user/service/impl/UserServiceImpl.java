package com.hospital.user.service.impl;

import com.hospital.user.dto.RegisterRequest;
import com.hospital.user.dto.UserResponse;
import com.hospital.user.entity.User;
import com.hospital.user.exception.UserAlreadyExistsException;
import com.hospital.user.mapper.UserMapper;
import com.hospital.user.repository.UserRepository;
import com.hospital.user.service.UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class UserServiceImpl implements UserService {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    private final UserMapper userMapper;

    @Override
    public UserResponse register(RegisterRequest request) {

        if (userRepository.existsByEmail(request.getEmail())) {
            throw new UserAlreadyExistsException("Email already exists");
        }

        if (userRepository.existsByPhoneNumber(request.getPhoneNumber())) {
            throw new UserAlreadyExistsException("Phone number already exists");
        }

        User user = userMapper.toEntity(request);

        // Encode password before saving
        user.setPassword(passwordEncoder.encode(request.getPassword()));

        User savedUser = userRepository.save(user);

        return userMapper.toResponse(savedUser);
    }
}