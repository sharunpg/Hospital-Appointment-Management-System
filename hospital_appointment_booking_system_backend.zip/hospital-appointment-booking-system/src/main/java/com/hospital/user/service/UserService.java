package com.hospital.user.service;

import com.hospital.user.dto.RegisterRequest;
import com.hospital.user.dto.UserResponse;

public interface UserService {

    UserResponse register(RegisterRequest request);

}